from flask import Flask, render_template, request
#import mysql.connector as sql
import sqlite3 as db;

app = Flask(__name__)

#con = sql.connect(host='*****', user='****', password='*****', database='****');

l = []

con = db.connect ('site.db', check_same_thread=False);
c = con.cursor();

@app.route('/index')
@app.route('/')
def index():
	return render_template ('blog/index.html', val = l, tit = "Home Page", msg = "");

@app.route('/create_table')
def create_table():
	c.execute("create table todo (name varchar(20))");
	con.commit();
	return render_template ('blog/index.html', val = l, tit = "Home Page", msg = "Table Created Successfuuly");

@app.route('/insert_data', methods = ['post', 'get'])
def insert_data():
	d = request.form.get("t1");
	print(d);
	c.execute("insert into todo values (?)",(d,));
	c.execute("select * from todo");
	result = c.fetchall();
	con.commit();
	return render_template ('blog/index.html', val = result, tit = "Home Page", msg = "Value Inserted Successfully");

if __name__ == "__main__":
	app.run (debug = True, host='0.0.0.0', port=8080);
